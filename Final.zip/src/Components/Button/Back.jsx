import React from 'react'
import { IoMdArrowRoundBack } from "react-icons/io";
function Back() {
    return (
        <div>
            <button className='btn  mb-2'>
                <IoMdArrowRoundBack />
            </button>
        </div>
    )
}

export default Back